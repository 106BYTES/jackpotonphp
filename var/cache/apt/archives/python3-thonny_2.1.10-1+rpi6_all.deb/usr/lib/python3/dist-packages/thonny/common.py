# This is a proxy module which gives frontend the illusion 
# that common lives directly in thonny package
# (this is the case for backend)
from thonny.shared.thonny.common import *  # @UnusedWildImport
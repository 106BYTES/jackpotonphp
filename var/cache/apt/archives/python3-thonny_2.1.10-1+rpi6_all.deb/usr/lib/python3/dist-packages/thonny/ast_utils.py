# This is a proxy module which gives frontend the illusion 
# that ast_utils lives directly in thonny package
# (this is the case for backend)
from thonny.shared.thonny.ast_utils import *  # @UnusedWildImport
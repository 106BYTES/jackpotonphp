# Frontend will interpret this folder as thonny.shared.thonny
# For backend parent folder will be in path, so this will be package thonny
APCu Backwards Compatibility Module
===============================

[![Build Status](https://travis-ci.org/krakjoe/apcu-bc.svg?branch=master)](https://travis-ci.org/krakjoe/apcu-bc)

This module provides a backwards APC compatible API using [APCu](https://github.com/krakjoe/apcu).
